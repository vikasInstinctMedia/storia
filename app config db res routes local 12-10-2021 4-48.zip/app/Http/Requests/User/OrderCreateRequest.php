<?php

namespace App\Http\Requests\User;

use Illuminate\Foundation\Http\FormRequest;

class OrderCreateRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'firstname'        => 'required',
            'lastname'         => 'required',
            'customer_country' => 'required',
            'customer_state'   => 'required',
            'city'             => 'required',
            'address'          => 'required',
            'zip'              => 'required|digits:6    ',
            'phone'            => 'required|digits:10',
            'address'          => 'required',
        ];
    }
    
    public function messages()
    {
        return [

        ];
    }
}
