<?php

namespace App\Http\Controllers\Front;


use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use Auth;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Session;
use Illuminate\Support\Facades\Input;
use Validator;
use App\CustomClasses\ColectionPaginate;
use App\Traits\CartTrait;
use DB;
use App\Traits\CommonDataTrait;

class CatalogController extends Controller
{
    use CartTrait, CommonDataTrait;

    // CATEGORIES SECTON

    public function categories()
    {
        return view('front.categories');
    }

    /**
     * @author Aakash and piyush
     * loading page as per the slug, since there is same URL structure for both. 
     * /{slug}
     * 
     */

    public function category($slug) 
    {
      $data['trending_products'] = $this->getTrendingProductList();

      $category = Category::where('slug', $slug)->active()->first();
      
      // dd($category->products->first()->base_pack->details->title);
      if($category) {

        $products = $category->products
                  ->load('product', 'product.packs', 'product.packs.details', 'product.packs.inventory')
                  ->pluck('product');
        // dd($products->first());
        // $category->products->load('packs', 'packs.details');
        // Get all the products related to category
        $products = $products->where('is_active',1)->sortByDesc('is_featured');
        // dd($products);
        // $products->append('base_pack');
        $data['category'] = $category;

        $products = $products->map(function ($product) {
                          $product->append(['base_pack_price', 'base_pack']);
                          return $product;
                        });

        $data['prods']    = ColectionPaginate::paginate($products, 15);

        $data['products'] = $products;


        
        // dd($data);
        return view('front.products', $data);
      } 

      $product = Product::where('slug', $slug)->active()->first();

      if($product) {
        $product->append('base_pack_price');
        // Get specific product for details page
        $data['product'] = $product->load('seo', 'packs', 'images');
        // $this->loadAllInformationInJson();
        // dd($product->categories()->first()->category->id);
        $data['faqs']    = $this->getFAQs($product->categories());
        
        // dd($product);
        // dd($product->includedProducts);

        return view('front.product_details', $data);
      }

      abort(404);
    }

    private function loadAllInformationInJson()
    {
      $products = Product::all();

      
        foreach($products as $product) {
          $arrayInformation = [];
          $elements = explode("\r\n", $product->nutritional_information);

          foreach($elements as $value) {
            $keyValue = explode('-',$value);
            // if(empty($keyValue[1])) {
            //   dump($product);
            //   dd( $product->nutritional_information);
            // }
            $arrayInformation[$keyValue[0]] = $keyValue[1];
          }
          
          $product->nutritional_information_json = json_encode($arrayInformation);
          // dd($arrayInformation);
          $product->save();
        }
     

    }

    
   

}
