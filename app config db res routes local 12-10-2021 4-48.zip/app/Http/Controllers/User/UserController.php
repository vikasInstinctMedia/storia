<?php

namespace App\Http\Controllers\User;

use App\Helpers\OrderStatusConstants;
use App\Helpers\ShippingAPIHelper;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Order;
use App\Models\Pack;
use App\Models\Product;
use Exception;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /*---------------- Index ---------------- */

    public function index()
    {
        $user = Auth::user();

        // Maybe for recent orders tab
        $orderss = Order::query()
            ->where('user_id', $user->id)
            ->orderByDesc('id')
            ->get();


        // Maybe for dashboard orders tab

        $dashboardOrders = $user->orders()
            ->latest()
            ->get();

        $dashboardOrders = $this->fetchTrackingData($dashboardOrders);



        return view('user.dashboard', compact('user', 'dashboardOrders','orderss'));
    }


    /*---------------- Fetch Tracking Data ---------------- */

    private function fetchTrackingData($orders): Collection
    {

        try {

            $filteredOrders = $orders->whereNotIn('status', [
                Order::COMPLETED,
                Order::DECLINED
            ]);

            $helper = new ShippingAPIHelper();

            foreach ($filteredOrders as $key => $order) {

                $trackingDataCollection = $helper->trackOrder($order->awb_number);

//                dd($trackingDataCollection[count($trackingDataCollection) - 1]);

                $orders[$key]->tracking_status = $trackingDataCollection->last()->message;
            }


            return $orders;

        } catch (Exception $e) {
            info("Tracking API User PAGE === " . $e->getMessage());
            return $orders;
        }

    }

    public function create_pack(){
        $categories = Category::active()->get();
        $packs = Pack::all();
        $products = Product::where('type','regular')->get();
        return view('user.create-pack', compact('categories','packs','products'));
    }

    public function save_pack(){
        print_r($_POST);
        exit;
    }
}
