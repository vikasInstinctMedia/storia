<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Auth;
use Validator;

class RegisterController extends Controller
{

	public function showRegisterForm()
    {

      return view('user.register');
    }


    public function register(Request $request)
    {
 
        $rules = [
        		'name'   => 'required',
		        'email'   => 'required|email|unique:users',
		        'password' => 'required'
                ];
        $validator = Validator::make($request->all(), $rules);
        
        if ($validator->fails()) {
          return response()->json(array('errors' => $validator->getMessageBag()->toArray()));
        }
        //--- Validation Section Ends

        $user = new User;
        $input = $request->all();        
        $input['password'] = bcrypt($request['password']);
		  
		    $user->fill($input)->save();

        Auth::guard('web')->login($user);
        return response()->json(1);
       // return response()->json('You are register Successfully..');
    }

}