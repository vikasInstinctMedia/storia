<?php
use Illuminate\Support\Facades\Route;

// Routes with Prefix admin/

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\LoginController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\BranchController;
use App\Http\Controllers\Admin\OrderController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\InventoryController;
use App\Http\Controllers\Admin\CouponController;
use App\Http\Controllers\Admin\TestimonialController;
use App\Http\Controllers\Admin\UserController;

Route::redirect('/', 'dashboard');

Route::get('login', [LoginController::class, 'index'])->name('admin.login');

Route::post('login', [LoginController::class, 'login'])->name('admin.auth');
Route::get('logout', [LoginController::class, 'logout'])->name('admin.logout');

Route::group(['middleware'=>['auth:admin', 'verify_role:admin'], 'as' => 'admin.'], function() {

    Route::get('dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');
    Route::get('get_chart_data', [DashboardController::class, 'getDataForChart'])->name('chart_data');

    // Category //
    Route::get('categories/getlist', [CategoryController::class, 'getList'])->name('categories.getlist');
    Route::post('categories/faq/update', [CategoryController::class, 'updateFaq'])->name('categories.faq.update');
    Route::get('categories/faq/delete/{faq_id}', [CategoryController::class, 'deleteFaq'])->name('categories.faq.delete');
    Route::resource('categories', CategoryController::class);

    // Product //
    Route::get('products/getlist', [ProductController::class, 'getList'])->name('products.getlist');
    Route::resource('products', ProductController::class);

    // Branch //
    Route::get('branches/getlist', [BranchController::class, 'getList'])->name('branches.getlist');
    Route::resource('branches', BranchController::class);

    // Coupon //
    Route::resource('coupons', CouponController::class);

    // Inventory //
    Route::get('branches/inventory/{branch}', [InventoryController::class, 'index'])->name('branches.inventory.index');
    Route::get('branches/inventory/getlist/{branch}', [InventoryController::class, 'getInventroyList'])->name('branches.inventory.getlist');
    Route::post('branches/inventory/update/quantity', [InventoryController::class, 'updateQuantity'])->name('branches.inventory.updatequantity');
    Route::get('branches/inventory/export/template/{branch_id}', [InventoryController::class, 'exportTemplateForInventory'])->name('branches.inventory.export_template');
    Route::get('branches/inventory/import/stock/{branch_id}', [InventoryController::class, 'importStockView'])->name('branches.inventory.import_view');
    Route::post('branches/inventory/import/stock', [InventoryController::class, 'importStock'])->name('branches.inventory.import');

    // Order //
    Route::get('orders/getlist', [OrderController::class, 'getList'])->name('orders.getlist');
    Route::get('orders/index', [OrderController::class, 'index'])->name('orders.index');
    Route::post('orders/update_status', [OrderController::class, 'updateStatus'])->name('orders.update.status');
    Route::get('orders/show/{order}', [OrderController::class, 'show'])->name('orders.show');

    // User //
    Route::get('users/getlist', [UserController::class, 'getList'])->name('users.getlist');
    Route::resource('users', UserController::class)->only('index', 'show', 'update');

    // Setting //
    Route::group(['as' => 'settings.', 'prefix' => 'settings'], function() {
        // Banner //
        Route::get('banner/index', [SettingController::class, 'bannerIndex'])->name('banner.index');
        Route::post('banner/store', [SettingController::class, 'bannerStore'])->name('banner.store');
        Route::post('banner/seq/store', [SettingController::class, 'bannerSeqStore'])->name('banner.seq.store');
        Route::get('banner/delete/{banner}', [SettingController::class, 'bannerDelete'])->name('banner.delete');

        // Testimonials //
        Route::resource('testimonials', TestimonialController::class);

    });

});


// Route::group(['middleware'=>['auth:admin'],'as' => 'admin.cfa.', 'prefix' => 'cfa'], function() {
//     Route::get('dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');
// });

Route::get('clear_cache', function () {

    \Artisan::call('cache:clear');
    \Artisan::call('config:cache');
    \Artisan::call('route:cache');

    dd("Cache is cleared");

});
