@extends('layouts.front')
@section('style')
<style>
	.centered {
		text-align: center;
		font-size: 0;
	}

	.centered>div {
		/* float: none; */
		display: inline-block;
		/* text-align: left; */
		font-size: 13px;
	}
</style>
@endsection

@section('content')
<div id="main">
	<!-- <div class="section section-bg-10 pt-11 pb-17">
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<h2 class="page-title text-center">Shop Detail</h2>
						</div>
					</div>
				</div>
			</div>
			<div class="section border-bottom pt-2 pb-2">
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<ul class="breadcrumbs">
								<li><a href="./">Home</a></li>
								<li><a href="shortcodes.html">Shop</a></li>
								<li>Shop Detail</li>
							</ul>
						</div>
					</div>
				</div>
			</div> -->
	<div class="section pt-7 pb-7">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="single-productt">
						<div class="col-md-6">
							<div class="image-gallery">
								<div class="image-gallery-inner">
                                @if (!empty($product->images))
									@foreach($product->images as $image)
									<div>
										<div class="image-thumb">
											<a href="#" data-rel="prettyPhoto[gallery]">
												<img src="{{ asset('storage/'.$image->image) }}" alt="" />
											</a>
										</div>
									</div>
									@endforeach
                                @endif
								</div>
							</div>
							<div class="image-gallery-nav">
                                @if (isset($product->images) && !empty($product->images))

								@foreach($product->images as $image)
								<div class="image-nav-item">
									<div class="image-thumb">
										<img src="{{ asset('storage/'.$image->image) }}" alt="" height="100" width="100" />
									</div>
								</div>
								@endforeach

                                @endif
							</div>
						</div>
						<div class="col-md-6">
							<div class="summary">
								<h3 class="product-title"> {{ ucwords($product->name) }} </h3>
								<!-- <div class="product-rating">
									<div class="star-rating">
										<span style="width:100%"></span>
									</div>
									<i>(2 customer reviews)</i>
								</div> -->

								<div class="product-price pt-1 pb-1">
									{{--
											@if($product->price_without_discount)
											<del>₹{{ $product->price_without_discount }}</del>
									@endif
									--}}

                                    @if ($product->type == 'regular')
									<ins>₹ <span id="pack-price">{{ $product->base_pack_price }}</span></ins>
                                    @endif

                                    @if ($product->type == 'assorted')
                                    <ins>₹<span class="pack-price">{{ ($product->base_pack_price - $product->base_pack->discount) }}</span> </ins>
                                    @endif
								</div>
								<div class="mb-3 product-info summary1235">
									<p>{{ mb_convert_encoding($product->description, "UTF-8"); }}</p>
								</div>
								<form class="commerce-ordering karho">
									<select name="packs" class="packs pack-select" data-product-id="{{ $product->id }}" id="pack">
										@if (isset($product->packs) && !empty($product->packs))

                                        @foreach($product->packs as $pack)
										<option value="{{ $pack->id }}" {{ $loop->index == 0? 'selected':"" }}>{{ $pack->details->title }}</option>
										@endforeach

                                        @endif
									</select>
								</form>

								<form class="cart karho">
									<button id="in-stock" type="submit" class="single-add-to-cart add-to-cart add-to-cart-btn {{ !$product->base_pack->is_product_in_stock ? 'd-none' : '' }}" data-product-id="{{ $product->id }}">ADD TO CART</button>
									<span id="not-in-stock" class="ml-1 {{ !$product->base_pack->is_product_in_stock ? '' : 'd-none' }}"> out of stock</span>
									<!-- <div class="quantity-chooser">
												<div class="quantity">
													<span class="qty-minus" data-min="1"><i
															class="ion-ios-minus-outline"></i></span>
													<input type="text" name="quantity" value="1" title="Qty"
														class="input-text qty text" size="4">
													<span class="qty-plus" data-max=""><i
															class="ion-ios-plus-outline"></i></span>
												</div>
											</div> -->
								</form>



							</div>
						</div>

						<div class="col-lg-12 col-xs-12 mt-2 bg-light pt-2 pb-2 mb-2" style="color: #000;">
							<div class="col-lg-12">
								<!-- <h3 class="product-title" style="color: #000;">{{ ucwords($product->name) }}</h3> -->
								<p class="fairfruit"></p>
							</div>
							@if($product->usp)
							<div class="col-lg-12">
								<!-- USP section -->
								<div class="mb-3 storiabrand" style="text-align:center">
                                    @if (isset($product->usp) && $product->usp != '')
									@foreach(json_decode($product->usp) as $usp)
									<div class="col-lg-3 col-md-3 col-xs-6 storaddf">
										<img src="{{ asset('storage/'. $usp->usp_icon) }}">
										<p>{{ ucwords($usp->usp) }}</p>
									</div>
									@endforeach
                                    @endif
								</div>
							</div>
							@endif
						</div>



						@if($product->ingredients)
						<div class="col-lg-12 col-xs-12 mt-2 bg-light pt-2 pb-2 mb-2" style="color: #000;">
							<div class="col-lg-12">
								<h3 class="product-title text-center" style="color: #000;">Ingredients</h3>
								<!-- <p class="fairfruit text-center">Equivalent to 100% fruit Juice</p> -->
							</div>
							<div class="col-lg-12">
								<div class="mb-3 storiabrand text-center centered">
                                    @if (isset($product->ingredients) && $product->ingredients != '')

									@foreach(json_decode($product->ingredients) as $ingredient)
									<div class="col-lg-4 col-md-4 col-xs-6 storaddf">
										<img src="{{ asset('storage/'. $ingredient->ingredient_icon ) }}">
										<p>{{ ucwords($ingredient->ingredient) }}</p>
									</div>
									@endforeach

                                    @endif
								</div>
							</div>
						</div>
						@endif

						@if($product->type == 'assorted')
						<div class="col-lg-12 col-xs-12 mt-2 bg-light pt-2 pb-2 mb-2" style="color: #000;">
							<div class="col-lg-12 mb-2">
								<h3 class="product-title text-center" style="color: #000;">Pack Contains</h3>

							</div>
							<div class="col-lg-12">
								<div class="mb-3 storiabrand text-center centered">
									@if (isset($product->includedProducts) && !empty($product->includedProducts))

                                    @foreach($product->includedProducts as $includedProduct)
									<div class="col-lg-2 col-md-2 col-xs-6">
										<img src="{{ asset('storage/'. $includedProduct->details->banner_image) }}" width="">
										<p>{{ ucwords($includedProduct->details->name) }}</p>
									</div>
									@endforeach

                                    @endif
								</div>
							</div>
						</div>
						@endif

                        <div class="col-lg-12 col-xs-12 mt-2 bg-dark pt-2 pb-2 mb-2" style="color: #fff;">
							<div class="col-lg-12">
								<h3 class="product-title text-center" style="color: #fff;">{{ $product->know_your_fruit_title }}</h3>
								<p class="fairfruit text-center">{{ $product->know_your_fruit_desc }}</p>
							</div>
							@if($product->fruiticons)
							<div class="col-lg-12">
								<div class="mb-3 storiabrand" style="text-align:center">
                                    @if (isset($product->fruiticons) && $product->fruiticons != '')
									@foreach(json_decode($product->fruiticons) as $fruiticon)
									<div class="col-lg-3 col-md-3 col-xs-6 storaddf">
										<img src="{{ asset('storage/'. $fruiticon->fruiticon_icon ) }}">
										<p>{{ $fruiticon->fruiticon }}</p>
									</div>
									@endforeach
                                    @endif
								</div>
							</div>
							@endif
						</div>

						@if($product->nutritional_information_json)
						<div class="col-lg-12 col-xs-12 mt-2 bg-light pt-2 pb-2 mb-2">
							<h3 class="product-title text-center" style="color: #000;">Nutritional Information</h3>

							<div class="product-info">
								<table class="blueTable">
									<tbody>
                                        @if (isset($product->nutritional_information_json) && $product->nutritional_information_json != '')

										@foreach(json_decode($product->nutritional_information_json) as $title => $value)
										<tr>
											<td>{{ $title }}</td>
											<td>{{ $value }}</td>
										</tr>
										@endforeach

                                        @endif
									</tbody>
								</table>
							</div>


						</div>
						@endif
						<div class="col-lg-12">
							<div class="commerce-tabs tabs classic">
								<ul class="nav nav-tabs tabs mb-4">
									<li class="active">
										<a data-toggle="tab" href="#tab-description" aria-expanded="true">FAQs</a>
									</li>
									<li class="">
										<a data-toggle="tab" href="#tab-reviews" aria-expanded="false">Reviews</a>
									</li>
								</ul>
								<div class="tab-content">
									<div class="tab-pane fade active in" id="tab-description">
										<div class="col-sm-12 bg-light">
											<div class="accordion icon-default icon-right" id="accordion3">

												@forelse($faqs as $faq)

												<div class="accordion-group toggle">
													<div class="accordion-heading toggle_title">
														<a class="accordion-toggle" data-toggle="collapse" aria-expanded="true" aria-controls="collapse{{ $faq->id }}" href="#collapse{{ $faq->id }}">
															{!! $faq->question !!}
														</a>
														<span class="icon"><i class="ion-plus-circled"></i></span>
													</div>
													<div id="collapse{{ $faq->id }}" class="bg-light accordion-body collapse ">
														<div class="accordion-inner">
															<p>
																{!! $faq->answer !!}
															</p>
														</div>
													</div>
												</div>

												@empty

												@endif

											</div>
										</div>
									</div>
									<div id="tab-reviews" class="tab-pane fade">
										<!-- <div class="single-comments-list mt-0">
											<div class="mb-2">
												<h4 class="comment-title">2 reviews for NIMBU PANI</h4>
											</div>
											<ul class="comment-list">
												<li>
													<div class="comment-container">
														<div class="comment-author-vcard">
															<img alt="" src="images/avatar/avatar_100x100.jpg" />
														</div>
														<div class="comment-author-info">
															<span class="comment-author-name">admin</span>
															<a href="#" class="comment-date">July 27, 2016</a>
															<p>Far far away, behind the word mountains, far from
																the countries Vokalia and Consonantia, there
																live the blind texts. Separated they live in
																Bookmarksgrove right at the coast of the
																Semantics, a large language ocean. A small river
																named Duden flows by their place and supplies it
																with the necessary regelialia.</p>
														</div>
														<div class="reply">
															<a class="comment-reply-link" href="#">Reply</a>
														</div>
													</div>
													<ul class="children">
														<li>
															<div class="comment-container">
																<div class="comment-author-vcard">
																	<img alt="" src="images/avatar/avatar_100x100.jpg" />
																</div>
																<div class="comment-author-info">
																	<span class="comment-author-name">admin</span>
																	<a href="#" class="comment-date">July 27,
																		2016</a>
																	<p>Far far away, behind the word mountains,
																		far from the countries Vokalia and
																		Consonantia, there live the blind texts.
																		Separated they live in Bookmarksgrove
																		right at the coast of the Semantics, a
																		large language ocean. A small river
																		named Duden flows by their place and
																		supplies it with the necessary
																		regelialia.</p>
																</div>
																<div class="reply">
																	<a class="comment-reply-link" href="#">Reply</a>
																</div>
															</div>
														</li>
													</ul>
												</li>
												<li>
													<div class="comment-container">
														<div class="comment-author-vcard">
															<img alt="" src="images/avatar/avatar_100x100.jpg" />
														</div>
														<div class="comment-author-info">
															<span class="comment-author-name">admin</span>
															<a href="#" class="comment-date">July 27, 2016</a>
															<p>Far far away, behind the word mountains, far from
																the countries Vokalia and Consonantia, there
																live the blind texts. Separated they live in
																Bookmarksgrove right at the coast of the
																Semantics, a large language ocean. A small river
																named Duden flows by their place and supplies it
																with the necessary regelialia.</p>
														</div>
														<div class="reply">
															<a class="comment-reply-link" href="#">Reply</a>
														</div>
													</div>
												</li>
											</ul>
										</div>
										<div class="single-comment-form mt-0">
											<div class="mb-2">
												<h4 class="comment-title">LEAVE A REPLY</h4>
											</div>
											<form class="comment-form">
												<div class="row">
													<div class="col-md-12">
														<textarea id="comment" name="comment" cols="45" rows="5" placeholder="Message *"></textarea>
													</div>
												</div>
												<div class="row">
													<div class="col-md-4">
														<input id="author" name="author" type="text" value="" size="30" placeholder="Name *" class="mb-2">
													</div>
													<div class="col-md-4">
														<input id="email" name="email" type="email" value="" size="30" placeholder="Email *" class="mb-2">
													</div>
													<div class="col-md-4">
														<input id="url" name="url" type="text" value="" placeholder="Website">
													</div>
												</div>
												<div class="row">
													<div class="col-md-2">
														<input name="submit" type="submit" id="submit" class="btn btn-alt btn-border" value="Submit">
													</div>
												</div>
											</form>
										</div> -->
									</div>
								</div>
							</div>
							<div class="related" style="display: none;">
								<div class="related-title">
									<div class="text-center mb-1 section-pretitle fz-34">Related</div>
									<h2 class="text-center section-title mtn-2 fz-24">Products</h2>
								</div>
								<div class="product-carousel p-0" data-auto-play="true" data-desktop="3" data-laptop="2" data-tablet="2" data-mobile="1">
									<div class="product-item text-center">
										<div class="product-thumb">
											<a href="shop-detail.html">
												<div class="badges">
													<span class="hot">Hot</span>
												</div>
												<img src="images/shop/shop_260x260.jpg" alt="" />
											</a>
											<div class="product-action">
												<span class="add-to-cart">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Add to cart"></a>
												</span>
												<span class="wishlist">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Add to wishlist"></a>
												</span>
												<span class="quickview">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Quickview"></a>
												</span>
												<span class="compare">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Compare"></a>
												</span>
											</div>
										</div>
										<div class="product-info">
											<a href="shop-detail.html">
												<h2 class="title">Carrot</h2>
												<span class="price">₹12.00</span>
											</a>
										</div>
									</div>
									<div class="product-item text-center">
										<div class="product-thumb">
											<a href="shop-detail.html">
												<span class="outofstock"><span>Out</span>of stock</span>
												<img src="images/shop/shop_260x260.jpg" alt="" />
											</a>
											<div class="product-action">
												<span class="add-to-cart">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Add to cart"></a>
												</span>
												<span class="wishlist">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Add to wishlist"></a>
												</span>
												<span class="quickview">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Quickview"></a>
												</span>
												<span class="compare">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Compare"></a>
												</span>
											</div>
										</div>
										<div class="product-info">
											<a href="shop-detail.html">
												<h2 class="title">Sprouting Broccoli</h2>
												<span class="price">₹6.00</span>
											</a>
										</div>
									</div>
									<div class="product-item text-center">
										<div class="product-thumb">
											<a href="shop-detail.html">
												<img src="images/shop/shop_260x260.jpg" alt="" />
											</a>
											<div class="product-action">
												<span class="add-to-cart">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Add to cart"></a>
												</span>
												<span class="wishlist">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Add to wishlist"></a>
												</span>
												<span class="quickview">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Quickview"></a>
												</span>
												<span class="compare">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Compare"></a>
												</span>
											</div>
										</div>
										<div class="product-info">
											<a href="shop-detail.html">
												<h2 class="title">Chinese Cabbage</h2>
												<span class="price">₹9.00</span>
											</a>
										</div>
									</div>
									<div class="product-item text-center">
										<div class="product-thumb">
											<a href="shop-detail.html">
												<div class="badges">
													<span class="hot">Hot</span>
												</div>
												<img src="images/shop/shop_260x260.jpg" alt="" />
											</a>
											<div class="product-action">
												<span class="add-to-cart">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Add to cart"></a>
												</span>
												<span class="wishlist">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Add to wishlist"></a>
												</span>
												<span class="quickview">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Quickview"></a>
												</span>
												<span class="compare">
													<a href="#" data-toggle="tooltip" data-placement="top" title="Compare"></a>
												</span>
											</div>
										</div>
										<div class="product-info">
											<a href="shop-detail.html">
												<h2 class="title">Tieton Cherry</h2>
												<span class="price">₹9.00</span>
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				{{-- @include('includes.catalog') --}}
			</div>
		</div>
	</div>
</div>
@endsection

@section('scripts')

<script>
	$('.slider').slick({
		arrows: false
	});

	$(function() {
		var product = "{{ json_encode( $product->only([ 'name', 'base_pack', 'base_pack_price' ]) ) }}";
		product = product.replace( /&quot;/g, '"' ),
		product = JSON.parse( product );
		product.pack_id = product.base_pack.id;
		product.pack_price = product.base_pack_price;
		// console.log(product);

		analytics.productDetailsImpression(product);

	});
</script>
@endsection
