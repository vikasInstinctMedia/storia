@extends('layouts.front')
@section('style')
    <link rel="stylesheet" href="{{ asset('template/plugins/select2/css/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('template/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('template/plugins/dropzone/min/dropzone.min.css') }}">
@endsection
@section('content')

    <div id="main">
        <div class="container mt-5">
            <div class="row">
                <h2 class="text-center section-title mtn-2 fz-24 mb-3">Create Pack</h2>
                <form action="{{ route('user.save-user-pack') }}" method="post" id="create_user_pack_form" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="">Packs</label>
                            <div class="form-group row">
                                <div class="col-md-8">

                                    <select name="packs" class="form-control" id="packs" style="width: 100%;"
                                        autocomplete="off" required>
                                        <option value="">Select</option>
                                        @foreach ($packs as $pack)
                                            <option value="{{ $pack->id }}" data-qty="{{ $pack->quantity }}">{{ $pack->title }}</option>
                                        @endforeach
                                    </select>
                                    <input type="hidden" name="total_qty" id="total_qty">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="">Select Products</label>
                            <div class="form-group row" id="included_products_container" style="">
                                <div class="col-md-8">
                                    <select name="included_products[]" class="form-control" id="included_products"
                                        style="" >
                                        <option value="">Select</option>
                                        @foreach ($products as $product)
                                            <option value="{{ $product->id }}" data-name="{{ $product->name }}">{{ $product->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="add_pro_here">

                            </div>
                        </div>
                        <div class="col-md-6">
                            {{ csrf_field() }}
                            <input type="submit" value="submit" class="btn btn-success">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


@endsection
@section('scripts')
    <script src="{{ asset('template/plugins/bs-custom-file-input/bs-custom-file-input.min.js') }} "></script>

    <script src="{{ asset('template/plugins/select2/js/select2.full.min.js') }}"></script>

    <script src="{{ asset('template/plugins/dropzone/min/dropzone.min.js') }}"></script>

    <script>
        // $('#included_products').select2();

        $(document).on('change', '#type', function() {
            if ($("#type :selected").val() == 'assorted') {
                $('#included_products_container').css('display', '');
                return true;
            }
            $('#included_products_container').css('display', 'none');
        });

        $(document).on('change','#packs',function(){
            var cur_val = $(this).val();
            var data_qty = $(this).find(':selected').attr('data-qty');
            $('#total_qty').val(data_qty);
        });

        $(document).on('change','#included_products',function(){
            var cur_val = $(this).val();
            var pro_name = $(this).find(':selected').attr('data-name');
            // alert(pro_name);
            $('.add_pro_here').append('<div class="main_div"><div class="col-md-4"><label for="" class="pro_name">'+pro_name+'</label></div><div class="col-md-1"><label>X</label></div><div class="col-md-4"><input type="hidden" name="pro_id[]" class="form-control" value="'+cur_val+'"><input type="text" name="qty[]" class="form-control" placeholder="quantity" value="1" required></div><div class="col-md-1"><button type="button" class="btn btn-danger del_pro">X</button></div></div>');
        });

        $(document).on('submit','#create_user_pack_form',function(e){
            e.preventDefault();
        });

        $(document).on('click','.del_pro',function(){
            $(this).closest('.main_div').remove();
        });
    </script>
@endsection
