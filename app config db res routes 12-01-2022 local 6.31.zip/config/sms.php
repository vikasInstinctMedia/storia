<?php


return [

    'sms_alert' => [
        'key' => env('SMS_ALERT_KEY'),

        'template' => [

            'order_placed' => "Hello [name] thank you for placing your order [order_number] with Storia Foods Online Store."
        ]
    ]
];
