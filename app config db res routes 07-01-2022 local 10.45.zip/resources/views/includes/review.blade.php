<div class="section section-bg-7 section-cover pt-4 pb-8">
		<div class="col-sm-12">
			<h2 class="text-center section-title pb-4">We love our clients</h2>
			<div class="organik-seperator center">
				<span class="sep-holder"><span class="sep-line"></span></span>
				
				<span class="sep-holder"><span class="sep-line"></span></span>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="testimonial-carousel organik-testimonial style-3" data-auto-play="true" data-desktop="3" data-laptop="3" data-tablet="2" data-mobile="1">
						<div class="testi-item">
							<div class="text">
							Storia Street Style drinks have been a savior this lockdown. The taste takes me on a nostalgic ride, back to the days when I use to devour on street food.
							</div>
							<div class="info">
								<div class="photo">
									<img src="{{asset('front/images/avatar/review-3-120x120.jpg')}}" alt="" />
								</div>
								<div class="author">
									<span class="name">Harish Arora</span>
								
								</div>
							</div>
						</div>
						<div class="testi-item">
							<div class="text">
							I take pride in calling myself a foodie and Storia Street Style Juices complement almost all my food styles. They are refreshingly good and I always carry one of them.
							</div>
							<div class="info">
								<div class="photo">
									<img src="{{asset('front/images/avatar/review-2-120x120.jpg')}}" alt="" />
								</div>
								<div class="author">
									<span class="name">Julie D'Souza</span>
									
								</div>
							</div>
						</div>
						<div class="testi-item">
							<div class="text">
							I have tried all flavours of Storia Street Style Drinks and they have the most authentic taste. Guava Chilli is my favourite. You can try them and you’ll like them too.
							</div>
							<div class="info">
								<div class="photo">
									<img src="{{asset('front/images/avatar/review-1-120x120.jpg')}}" alt="" />
								</div>
								<div class="author">
									<span class="name">Aditya Mishra</span>
									
								</div>
							</div>
						</div>
						<div class="testi-item">
							<div class="text">
							Love this badam shake. It is healthy, natural and so delicious. Perfect as an evening snack.
							</div>
							<div class="info">
								<div class="photo">
									<img src="{{asset('front/images/avatar/Badam-1-120x120.jpg')}}" alt="" />
								</div>
								<div class="author">
									<span class="name">Swapnil Pawar</span>
									
								</div>
							</div>
						</div>
						<div class="testi-item">
							<div class="text">
							Best chocolate shake till now. It is thick, creamy and healthy too.
							</div>
							<div class="info">
								<div class="photo">
									<img src="{{asset('front/images/avatar/chocolate-1-120x120.jpg')}}" alt="" />
								</div>
								<div class="author">
									<span class="name">Sanjana Malwade</span>
									
								</div>
							</div>
						</div>
						<div class="testi-item">
							<div class="text">
							Storia Street Style drinks have been a savior this lockdown. The taste takes me on a nostalgic ride, back to the days when I use to devour on street food.
							</div>
							<div class="info">
								<div class="photo">
									<img src="{{asset('front/images/avatar/review-3-120x120.jpg')}}" alt="" />
								</div>
								<div class="author">
									<span class="name">Harish Arora</span>
								
								</div>
							</div>
						</div>
				
					</div>
				</div>
			</div>
		</div>
	</div>