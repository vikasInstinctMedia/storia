<?php
use Illuminate\Support\Facades\Route;

// Routes with Prefix admin/

use App\Http\Controllers\Admin\CFA\DashboardController;

Route::group(['middleware'=>['auth:admin', 'verify_role:branch_admin'], 'as' => 'admin.cfa.'], function() {
    Route::get('dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');

    Route::get('get_chart_data', [DashboardController::class, 'getDataForChart'])->name('chart_data');
    
});
