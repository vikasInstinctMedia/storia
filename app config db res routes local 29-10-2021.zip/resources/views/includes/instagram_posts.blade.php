<div class="section pt-7 pb-7">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="text-center">
						<div class="text-center mb-1 section-pretitle fz-34">Discover</div>
						<h2 class="text-center section-title mtn-2 fz-24">LETS CONNECT ON INSTAGRAMM</h2>
						<div class="product-carousel" data-auto-play="true" data-desktop="3" data-laptop="2" data-tablet="2" data-mobile="1">
							<div class="product-item text-center">
								<div class="product-thumb">
									<a href="shop-detail.html">
										<img src="{{asset('storage/instagram/218879240_886642778867088_895392387343937789_n.jpg')}}" alt="" />
									</a>
								</div>
							</div>
							<div class="product-item text-center">
								<div class="product-thumb">
									<a href="shop-detail.html">
										<img src="{{asset('storage/instagram/17873333615465232_320.jpg')}}" alt="" />
									</a>
								</div>
							</div>
							<div class="product-item text-center">
								<div class="product-thumb">
									<a href="shop-detail.html">
										<img src="{{asset('storage/instagram/17896969880156219_320.jpg')}}" alt="" />
									</a>
								</div>
							</div>
							<div class="product-item text-center">
								<div class="product-thumb">
									<a href="shop-detail.html">
										<img src="{{asset('storage/instagram/17908738486902379_320.jpg')}}" alt="" />
									</a>
								</div>
							</div>
							<div class="product-item text-center">
								<div class="product-thumb">
									<a href="shop-detail.html">
										<img src="{{asset('storage/instagram/17911720216787427_320.jpg')}}" alt="" />
									</a>
								</div>
							</div>
							<div class="product-item text-center">
								<div class="product-thumb">
									<a href="shop-detail.html">
										<img src="{{asset('storage/instagram/17925058831644489_320.jpg')}}" alt="" />
									</a>
								</div>
							</div>
							<div class="product-item text-center">
								<div class="product-thumb">
									<a href="shop-detail.html">
										<img src="{{asset('storage/instagram/17980709935376845_320.jpg')}}" alt="" />
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
