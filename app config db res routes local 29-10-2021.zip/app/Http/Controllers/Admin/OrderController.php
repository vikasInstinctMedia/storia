<?php

namespace App\Http\Controllers\Admin;

use App\Helpers\ShippingAPIHelper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Branch;
use App\Models\Order;
class OrderController extends Controller
{
    public function index()
    {
        $branches = Branch::all();
        return view('admin.order.index', compact('branches'));
    }

    public function getList(Request $request)
    {
        $orders = Order::with('user','branch')
                    ->when( $request->selected_branch ,  function($query , $selectedBranch ) {
                        return $query->where('branch_id', $selectedBranch);
                    })
                    ->latest()->get()->append('products');

        $branches = Branch::all();

        // dd($request->selected_branch);

        return datatables()->of($orders)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
                           return [
                                'view_url' => route('admin.orders.show',[ 'order' => $row->id])
                           ];
                    })
                    ->with([
                        'branches' => $branches,
                    ])
                    ->toJson();
    }

    public function update(Request $request)
    {

    }

    public function show(Order $order)
    {
        // dd($order->with(['billing_address']));
        // $withaddress = $order->billing_address;
        // echo '<pre>';
        // print_r($withaddress);
        // exit;
        return view('admin.order.show', compact('order') );
    }

    public function destroy()
    {

    }

    public function updateStatus(Request $request)
    {
        $order = Order::where('id', $request->order_id)->whereNotNull('awb_number')->firstOrFail();
        
        $status = (new ShippingAPIHelper())->cancelOrder($order->awb_number);

        if( ! $status) {
            return back()->with('error','Unable to cancel the order');
        }

        $order->status = Order::CANCELLED;
        
        if( ! $order->save()) {
            return back()->with('error','Something went wrong');
        }

        return back()->with('message', 'updated');
    }

}
