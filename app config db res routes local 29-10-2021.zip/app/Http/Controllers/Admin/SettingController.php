<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Banner;
use DB;
use App\Models\Category;
use Illuminate\Validation\Rule;

class SettingController extends Controller
{
    public function bannerIndex()
    {
        $banners = Banner::orderBy('sequence','ASC')->get();
        return view('admin.setting.banner_index', compact('banners'));
    }

    public function bannerStore(Request $request)
    {
        $request->validate([
            'image'        => ['required', 'mimes:jpeg,jpg,png', 'max:2024',
                                Rule::dimensions()->maxWidth(1940) ]
        ]);
        $data = $request->only('image', 'redirect_url');
        $data['image'] = $request->file('image')->store('banner');

        Banner::insert($data);

        return redirect()->route('admin.settings.banner.index')->with('message', 'created successfully');
    }

    public function bannerSeqStore(Request $request){
        $seq = $request->input('seq');
        $i = 1;
        foreach ($seq as $key => $value) {
            // $banner = Banner::where('id',$value)->first();
            // print_r($banner);
            // $banner->sequence = $i;
            // $banner->save();
            DB::table('banners')
            ->where('id', $value)
            ->update(['sequence' => $i]);
            $i++;
        }
        return redirect()->route('admin.settings.banner.index')->with('message', 'Sequence Updated');
        // exit;
    }

    public function bannerDelete(Banner $banner)
    {
        $banner->delete();
        return redirect()->route('admin.settings.banner.index')->with('message', 'Deleted');
    }

}
