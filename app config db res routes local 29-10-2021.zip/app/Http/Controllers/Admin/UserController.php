<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    public function index()
    {   
        return view('admin.user.index');
    }

    public function getList()
    {   
        $users = User::withCount('orders')->latest();

        // dd($allBranchProducts->get());
        return datatables()->of($users)
                    ->addIndexColumn()
                    // ->editColumn('thumbnail_image', function($row) {
                    //     return $row->thumbnail_image ? asset("storage/".$row->thumbnail_image) : "";
                    // })
                    ->addColumn('action', function($row){
                           return [
                                // 'view_url' => route('admin.categories.show',[ 'category' => $row->id]),
                                'edit_url' => route('admin.products.edit', ['product' => $row->id])
                           ];
                    })
                    ->toJson();
    }

    public function create()
    {
        return view('admin.branch.add');
    }

    public function store(Request $request)
    {
        dd($request->all());
    }

    public function update(Request $request)
    {

    }

    public function distroy()
    {
         
    }

    public function show()
    {
        
    }

}
