@extends('layouts.front')
@section('style')
<style>
.rest {
        font-family: Lato;
    }

    .rest h2 {
        font-family: Lato;
        text-align: center;
        border-bottom: 1px solid #ddd;
    }

    .rest p strong {
        border-bottom: 1px solid #000;
    }
</style>
@endsection
@section('content')

<div id="main">
    <div class="container">
        <div class="mb-5 ">
            <div class="rest">
                <h2 class="pb-2">Refund Policy</h2>
               <b> Thanks for shopping at www.shop.storiafoods.com,</b>
                <br><br>
If you find that the product delivered to you is unconsumable owing to quality, packaging and other
related issues, we&#39;re here to help. All products are eligible for refunds and return only if they’re kept at
0-8 degrees at all times, failing to store them as prescribed, shall lead to the product getting spoilt and
your claim will be not be entertained by Storia® Foods &amp; Beverages Pvt Ltd. (Storia®). . All refunds and
returns are at the sole discretion of Storia® Foods &amp; Beverages Pvt.Ltd. and shall be subject to
verification of your claim and its confirmation by its employees and management.
<br><br>
<b>RETURNS:</b> PRODUCT MUST BE RETURNED WITHIN 3 DAYS FROM ITS RECEIPT BY YOU.
<br><br>
To be eligible for a return, the product must be unused and in the same packaging and condition in
which it was received by you.
The Product must be accompanied by the receipt or proof of purchase (email invoice will also be
considered valid)
<br><br>
<b>REFUNDS :</b> On receipt of the product, the same shall be inspected and an intimation as regards its
receipt will be sent to you.
You will be immediately notified about the status of your refund after inspecting the product.
If your claim of return is approved, we will initiate a process of refund to your credit card (or original
method of payment).
You will receive the credit within a month, depending on your card issuer&#39;s policies.
<br><br>
Refunds and returns shall be entertained only if there’s a quality related issue with the product or its
non-delivery. Barring unforeseen circumstances, the refund will be given within 15 days of approval of
your Claim.
<br><br>
<b>CANCELLATIONS:</b> For cancellations please call us on +91 22 -28326831 or write to us on
customercare@storiafoods.com
<br><br>
<b>SHIPPING:</b> You need to keep the products ready so that our delivery boys can get them collected. We
will call and let you know when the next pick up will take place.
<br><br>
<b>CONTACT US:</b> If you have any questions on how to return your item to us, contact us on +91 22 -
28326831 or write to us on customercare@storiafoods.com
<br><br>
<h4 class="text-center">Returns &amp; Exchange Policy</h4>

www.shop.storiafoods.com OR “Storia® Foods &amp; Beverages Pvt.Ltd.” does not entertain returns after
the order is successfully placed and payment is made by the buyer. Buyers are requested to place the
order only if they agree with this term.
<br><br>
www.shop.storiafoods.com OR “Storia® Foods &amp; Beverages Pvt.Ltd.” will accept exchange of the sold
products through the website www.shop.storiafoods.com, subject to the terms and conditions
mentioned below: <br><br>
<ul style="margin-left: 52px">
    <li>Exchange requests will be entertained only in case the product(s) received by the buyer are in
        damaged or expired condition. Only such cases will be considered for exchange thereafter.</li>
    <li>Buyer has to inform www.shop.storiafoods.com OR “Storia® Foods &amp; Beverages Pvt.Ltd.” of
        his/her intention to exchange the damaged products within 2 hrs of receipt of the goods at
        his/her shipping address.</li>
    <li>Such damaged goods should be sent to “Storia® Foods &amp; Beverages Pvt.Ltd.” only after written
        email consent from www.shop.storiasfoods.com OR “Storia® Foods &amp; Beverages Pvt.Ltd.&quot; to
        send back the product.</li>
    <li>All replacements will be made after the returned shipment of product is received by Storia®
        Foods &amp; Beverages Pvt.Ltd. The courier charges for returning the damaged cases will be borne
        by “Storia® Foods &amp; Beverages Pvt.Ltd.”.</li>
    <li>If your claim of return is approved, we will initiate a process of refund to your credit card (or
        original method of payment).</li>
    <li>Return orders are to be sent back to the address from where it was dispatched to be confirmed
        from www.shop.storiafoods.com OR “Storia® Foods &amp; Beverages Pvt.Ltd.&quot;
        </li>
</ul>

<h4 class="text-center">Cancellation &amp; Refund Policy</h4>

You cannot cancel the order and demand refund once the order is successfully placed and processed by
the payment gateway. Refund requests will only be considered in the following cases:
<br><br>
If the shipping location is not serviced by our partner courier companies. No refund requests will be
entertained for damaged products. Damaged products will be exchanged as per our exchange policy.
<br><br>
From the date of written confirmation of refund to the customer, the amount will be refunded within
the next 7-10 business days. The amount will be refunded in the customer&#39;s mode of payment.
<br><br>
No Returns will be entertained if a customer wants to return the product for the reason that he/she
doesn&#39;t like it after delivery of the product or feels the product doesn&#39;t match his or her expectations.
No refunds will be given in the following cases:
<br><br>
<ul style="margin-left: 52px">
    <li>Incorrect or insufficient address mentioned by the customer</li>
    <li>Non- availability of recipient at the mentioned address and/or premises</li>
    <li>Refusal to accept products</li>
    <li>Delivered at the place/to the person specifically mentioned by the customer other than the
        customer himself</li>
    <li>Force majeure events.</li>
    <li>In case the product has undergone any tampering by the customer</li>
    <li>All emails in this regard are to be sent to customercare@storiafoods.com
    </li>
</ul>
<br><br>
<h4 class="text-center">COUPON TERMS &amp; CONDITIONS</h4>

Coupons are valid for a limited time only. Storia® Foods &amp; Beverages Pvt.Ltd. reserves the right to
modify or cancel coupons at any time.
<br><br>
The coupon offer will not be valid until it is applied to the qualifying item.
<br><br>
The coupon may only be used on www.shop.storiafoods.com and in conjunction with the purchase of
products shipped and sold by www.shop.storiafoods.com . The coupon is not valid on products sold by
third-party sellers or other e-commerce websites.
<br><br>
The coupon is limited to one coupon per customer.
<br><br>
If you return any of the items purchased with a coupon, the coupon discount or value may be subtracted
from the return credit.
<br><br>
Prevalent shipping and handling charges apply to all products as per the Shipping &amp; Returns Policy.
Offer good while supplies last.
<br><br>
Storia® Foods &amp; Beverages Pvt.Ltd. has no obligation for payment of any tax in conjunction with the
distribution or use of any coupon.
<br><br>
Consumers are required to pay any applicable taxes related to the use of the coupon.
<br><br>
Coupons shall be void if they are restricted or prohibited by law.
            </div>
        </div>
    </div>
</div>

@endsection

@section('scripts')

@endsection
