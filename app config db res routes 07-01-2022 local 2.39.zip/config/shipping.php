<?php


return [

    'nimbuspost' => [
        'email' => env('TRACKING_API_USER','demo@nimbuspost.com'),
        'secret' => env('TRACKING_API_PASSWORD','testdemo'),
    ]
];
