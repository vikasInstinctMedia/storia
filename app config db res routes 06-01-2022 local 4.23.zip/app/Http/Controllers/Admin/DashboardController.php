<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Helpers\ChartDataHelper;
use App\Http\Controllers\Controller;
use App\Models\Order;
use DB;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function dashboard()
    {
        $data['productCount']  = DB::table('products')->count();
        if(auth()->user()->roleIs('branch_admin'))
        {
            $orders = Order::with('user','branch')
            ->orderBy('created_at', 'desc');
            if(Auth::user()->branch_id!=""){
                $orders = $orders->where('branch_id', Auth::user()->branch_id);
            }
            $data['pendingOrders'] = $orders->count();
        }else{
            $data['pendingOrders'] = DB::table('orders')->whereIn('status', ['pending', 'processing'])->count();
        }
        $data['usersCount']    = DB::table('users')->count();
        $data['branchesCount']    = DB::table('branches')->count();

        $data['barChartData']  = ChartDataHelper::getOrderData('month');
        $data['barChartData']  = json_encode($data['barChartData']);
        // dd($data);
        return view('admin.dashboard', $data);
    }

    public function getDataForChart(Request $request)
    {
        // dd($request->all());
        $data['barChartData'] = ChartDataHelper::getOrderData($request->filterWith);
        return $this->successJsonResponse($data);

    }

}
