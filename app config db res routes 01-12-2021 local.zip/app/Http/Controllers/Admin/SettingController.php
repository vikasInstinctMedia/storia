<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Banner;
use App\Models\Setting;
use DB;
use App\Models\Category;
use Illuminate\Validation\Rule;

class SettingController extends Controller
{
    public function bannerIndex()
    {
        $banners = Banner::orderBy('sequence','ASC')->get();
        return view('admin.setting.banner_index', compact('banners'));
    }

    public function bannerStore(Request $request)
    {
        $request->validate([
            'image'        => ['required', 'mimes:jpeg,jpg,png', 'max:2024',
                                Rule::dimensions()->maxWidth(1940) ]
        ]);
        $data = $request->only('image', 'redirect_url');
        $data['image'] = $request->file('image')->store('banner');

        Banner::insert($data);

        return redirect()->route('admin.settings.banner.index')->with('message', 'created successfully');
    }

    public function bannerSeqStore(Request $request){
        $seq = $request->input('seq');
        $i = 1;
        foreach ($seq as $key => $value) {
            // $banner = Banner::where('id',$value)->first();
            // print_r($banner);
            // $banner->sequence = $i;
            // $banner->save();
            DB::table('banners')
            ->where('id', $value)
            ->update(['sequence' => $i]);
            $i++;
        }
        return redirect()->route('admin.settings.banner.index')->with('message', 'Sequence Updated');
        // exit;
    }

    public function bannerDelete(Banner $banner)
    {
        $banner->delete();
        return redirect()->route('admin.settings.banner.index')->with('message', 'Deleted');
    }

    public function about_us(){
        $about_us = Setting::where('key','about_us')->first();
        $about_us_data = json_decode($about_us->value,true);
        // print_r($about_us_data);
        // exit;
        return view('admin.setting.about_index', compact('about_us','about_us_data'));

    }

    public function about_us_store(Request $request){
        $request->validate([
            'image'        => ['required', 'mimes:jpeg,jpg,png', 'max:2024',
                                Rule::dimensions()->maxWidth(1940) ]
        ]);
        $data = $request->only('image', 'redirect_url','title','description');
        $data['image'] = $request->file('image')->store('banner');

        // Banner::insert($data);


        $about_data = Setting::where('key','about_us')->first();

        $get_data = json_decode($about_data->value,true);

        if(isset($get_data['slider_1'])){
            $cnt = count($get_data['slider_1']);
            // $save_data['slider_1'][$cnt+1] = $data;
            // $save_data = $get_data['slider_1'];
            array_push($get_data['slider_1'],$data);
        }else{
            $get_data['slider_1'][0] = $data;
        }

        // print_r($get_data);
        // exit;
        $about_data->value = json_encode($get_data);
        $about_data->save();

        return redirect()->route('admin.about-us')->with('message', 'Updated successfully');
    }


    public function about_us2_store(Request $request){
        $request->validate([
            'image'        => ['required', 'mimes:jpeg,jpg,png', 'max:2024',
                                Rule::dimensions()->maxWidth(1940) ]
        ]);
        $data = $request->only('image', 'redirect_url','title');
        $data['image'] = $request->file('image')->store('banner');

        // Banner::insert($data);


        $about_data = Setting::where('key','about_us')->first();

        $get_data = json_decode($about_data->value,true);

        if(isset($get_data['slider_2'])){
            $cnt = count($get_data['slider_2']);
            // $save_data['slider_2'][$cnt+1] = $data;
            // $save_data = $get_data['slider_2'];
            array_push($get_data['slider_2'],$data);
        }else{
            $get_data['slider_2'][0] = $data;
        }

        // print_r($get_data);
        // exit;
        $about_data->value = json_encode($get_data);
        $about_data->save();

        return redirect()->route('admin.about-us')->with('message', 'Updated successfully');
    }

}
