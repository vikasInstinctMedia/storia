<?php

use App\Http\Controllers\Admin\BlogController;
use Illuminate\Support\Facades\Route;

// Routes with Prefix admin/

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\LoginController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\BranchController;
use App\Http\Controllers\Admin\OrderController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\InventoryController;
use App\Http\Controllers\Admin\CouponController;
use App\Http\Controllers\Admin\RecipeController;
use App\Http\Controllers\Admin\TestimonialController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\Recpie;

Route::redirect('/', 'dashboard');

Route::get('login', [LoginController::class, 'index'])->name('admin.login');

Route::post('login', [LoginController::class, 'login'])->name('admin.auth');
Route::get('logout', [LoginController::class, 'logout'])->name('admin.logout');

Route::group(['middleware'=>['auth:admin', 'verify_role:admin'], 'as' => 'admin.'], function() {

    Route::get('dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');
    Route::get('get_chart_data', [DashboardController::class, 'getDataForChart'])->name('chart_data');

    Route::get('recipes/category/list', [RecipeController::class, 'category_index'])->name('recipes_category_list');
    Route::get('recipes/category/getlist', [RecipeController::class, 'categorygetlist'])->name('recipe.categories.getlist');
    Route::get('recipes/category/create', [RecipeController::class, 'category_create'])->name('recipe.categories.create');
    Route::post('recipes/category/store', [RecipeController::class, 'category_store'])->name('recipe.categories_store');
    Route::get('recipes/category/edit/{id}', [RecipeController::class, 'category_edit'])->name('recipe.category_edit');
    Route::post('recipes/category/update/{id}', [RecipeController::class, 'category_update'])->name('recipe.categories_update');
    Route::get('recipes/category/delete/{id}', [RecipeController::class, 'category_delete'])->name('recipe.categories_delete');


    Route::get('recipes/list', [RecipeController::class, 'recipe_index'])->name('recipes_list');
    Route::get('recipes/getlist', [RecipeController::class, 'recipegetlist'])->name('recipe.getlist');
    Route::get('recipes/create', [RecipeController::class, 'recipe_create'])->name('recipe.create');
    Route::post('recipes/store', [RecipeController::class, 'recipe_store'])->name('recipe.store');
    Route::get('recipes/edit/{id}', [RecipeController::class, 'recipe_edit'])->name('recipe.recipe_edit');
    Route::post('recipes/update/{id}', [RecipeController::class, 'recipe_update'])->name('recipe.recipe_update');
    Route::get('recipes/delete/{id}', [RecipeController::class, 'recipe_delete'])->name('recipe.recipe_delete');

    Route::get('blog/list', [BlogController::class, 'index'])->name('blog.list');
    Route::get('blog/getlist', [BlogController::class, 'getlist'])->name('blog.getlist');
    Route::get('blog/create', [BlogController::class, 'create'])->name('blog.create');
    Route::post('blog/store', [BlogController::class, 'store'])->name('blog.store');
    Route::get('blog/edit/{id}', [BlogController::class, 'edit'])->name('blog.edit');
    Route::post('blog/update/{id}', [BlogController::class, 'update'])->name('blog.update');
    Route::get('blog/delete/{id}', [BlogController::class, 'delete'])->name('blog.delete');

    // Category //
    Route::get('categories/getlist', [CategoryController::class, 'getList'])->name('categories.getlist');
    Route::post('categories/faq/update', [CategoryController::class, 'updateFaq'])->name('categories.faq.update');
    Route::get('categories/faq/delete/{faq_id}', [CategoryController::class, 'deleteFaq'])->name('categories.faq.delete');
    Route::resource('categories', CategoryController::class);

    // Product //
    Route::get('products/getlist', [ProductController::class, 'getList'])->name('products.getlist');
    Route::resource('products', ProductController::class);

    // Branch //
    Route::get('branches/getlist', [BranchController::class, 'getList'])->name('branches.getlist');
    Route::resource('branches', BranchController::class);

    // Coupon //
    Route::resource('coupons', CouponController::class);

        //Review
        Route::get('reviewReport',[UserController::class,'reviewReport'])->name('reviewReport');
        Route::post('reviewReplyAdd',[UserController::class,'reviewReplyAdd'])->name('reviewReplyAdd');
        Route::post('reviewStatusupdate',[UserController::class,'reviewStatusupdate'])->name('reviewStatusupdate');


    // Inventory //
    Route::get('branches/inventory/{branch}', [InventoryController::class, 'index'])->name('branches.inventory.index');
    Route::get('branches/inventory/getlist/{branch}', [InventoryController::class, 'getInventroyList'])->name('branches.inventory.getlist');
    Route::post('branches/inventory/update/quantity', [InventoryController::class, 'updateQuantity'])->name('branches.inventory.updatequantity');
    Route::get('branches/inventory/export/template/{branch_id}', [InventoryController::class, 'exportTemplateForInventory'])->name('branches.inventory.export_template');
    Route::get('branches/inventory/import/stock/{branch_id}', [InventoryController::class, 'importStockView'])->name('branches.inventory.import_view');
    Route::post('branches/inventory/import/stock', [InventoryController::class, 'importStock'])->name('branches.inventory.import');

    // Order //
    Route::get('orders/getlist', [OrderController::class, 'getList'])->name('orders.getlist');
    Route::get('orders/getlistByFilter', [OrderController::class, 'getlistByFilter'])->name('orders.getlistByFilter');
    Route::get('orders/index', [OrderController::class, 'index'])->name('orders.index');
    Route::post('orders/update_status', [OrderController::class, 'updateStatus'])->name('orders.update.status');
    Route::get('orders/show/{order}', [OrderController::class, 'show'])->name('orders.show');

    // User //
    Route::get('users/getlist', [UserController::class, 'getList'])->name('users.getlist');
    Route::resource('users', UserController::class)->only('index', 'show', 'update');

        //customer
        Route::get('customers', [UserController::class, 'customers'])->name('customers');
        Route::post('updateCustomer', [UserController::class, 'updateCustomer'])->name('updateCustomer');
        Route::get('customer/{id}/allorder', [UserController::class, 'allcustOrder'])->name('customer.allorder');
        Route::get('customer/{id}/delete', [UserController::class, 'delete_customer'])->name('customer.delete');
        Route::post('customer/filter', [UserController::class, 'allcustOrderfilter'])->name('customer.filter');
        Route::get('Transactional', [UserController::class, 'Transactional'])->name('Transactional');
        Route::get('productstock', [UserController::class, 'productstock'])->name('productstock');

        //pages
        Route::get('about-us', [SettingController::class, 'about_us'])->name('about-us');
        Route::post('about-us/save', [SettingController::class, 'about_us_store'])->name('settings.about_us.store');
        Route::post('about-us2/save', [SettingController::class, 'about_us2_store'])->name('settings.about_us2.store');


    // Setting //
    Route::group(['as' => 'settings.', 'prefix' => 'settings'], function() {
        // Banner //
        Route::get('banner/index', [SettingController::class, 'bannerIndex'])->name('banner.index');
        Route::post('banner/store', [SettingController::class, 'bannerStore'])->name('banner.store');
        Route::post('banner/seq/store', [SettingController::class, 'bannerSeqStore'])->name('banner.seq.store');
        Route::get('banner/delete/{banner}', [SettingController::class, 'bannerDelete'])->name('banner.delete');

        // Testimonials //
        Route::resource('testimonials', TestimonialController::class);

    });

});


// Route::group(['middleware'=>['auth:admin'],'as' => 'admin.cfa.', 'prefix' => 'cfa'], function() {
//     Route::get('dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');
// });

Route::get('clear_cache', function () {

    \Artisan::call('cache:clear');
    \Artisan::call('config:cache');
    \Artisan::call('route:cache');

    dd("Cache is cleared");

});
