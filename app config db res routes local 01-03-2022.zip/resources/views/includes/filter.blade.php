<div class="shop-filter">
	<div class="col-md-6">
		<p class="result-count"> </p>
	</div>
	<!-- <div class="col-md-6">
		<div class="shop-filter-right">
			<form class="commerce-ordering">
				<select name="orderby" class="orderby">
					<option value="">Sort by popularity</option>
					<option value="">Sort by average rating</option>
					<option value="" selected="selected">Sort by newness</option>
					<option value="">Sort by price: low to high</option>
					<option value="">Sort by price: high to low</option>
				</select>
			</form>
		</div>
	</div> -->
</div>