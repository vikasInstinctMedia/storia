<?php


namespace App\Helpers;
use Illuminate\Support\Facades\Http;

class FrontHelper {

    
    public static function getInstagramPosts()
    {
        // @todo 
        
    }

}