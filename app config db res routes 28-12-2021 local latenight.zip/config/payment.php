<?php


return [

    'razorpay' => [

        'test_key' => env('RAZORPAY_TEST_KEY'),
        'test_secret' => env('RAZORPAY_TEST_SECRET'),

        'live_key' => env('RAZORPAY_LIVE_KEY'),
        'live_secret' => env('RAZORPAY_LIVE_SECRET')
        
    ]
];
