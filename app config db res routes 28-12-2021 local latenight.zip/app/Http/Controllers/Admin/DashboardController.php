<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Helpers\ChartDataHelper;
use App\Http\Controllers\Controller;
use DB;

class DashboardController extends Controller
{
    public function dashboard()
    {           
        $data['productCount']  = DB::table('products')->count();
        $data['pendingOrders'] = DB::table('orders')->whereIn('status', ['pending', 'processing'])->count();
        $data['usersCount']    = DB::table('users')->count();
        $data['branchesCount']    = DB::table('branches')->count();

        $data['barChartData']  = ChartDataHelper::getOrderData('month');
        $data['barChartData']  = json_encode($data['barChartData']);
        // dd($data);
        return view('admin.dashboard', $data);
    }

    public function getDataForChart(Request $request)
    {
        // dd($request->all());   
        $data['barChartData'] = ChartDataHelper::getOrderData($request->filterWith);
        return $this->successJsonResponse($data);

    }

}
