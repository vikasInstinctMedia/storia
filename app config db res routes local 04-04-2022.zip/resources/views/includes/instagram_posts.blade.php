<div class="section pt-7 pb-7">

    <div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="text-center insposts">
						<div class="text-center mb-1 section-pretitle fz-34">Discover</div>
						<h2 class="text-center section-title mtn-2 fz-24">LETS CONNECT ON INSTAGRAM</h2>
						<div id="" class="product-carousel" data-auto-play="true" data-desktop="3" data-laptop="2" data-tablet="2" data-mobile="1">

                           @for ($i = 0; $i < 5; $i++)




                            <div class="product-item text-center">
								<div id="" class="product-thumb">
									<a href="#">
										<img src="#" alt="" />
									</a>
								</div>


							</div>

                            @endfor
						</div>

                        <div id="instafeed-container">

                        </div>

					</div>
				</div>
			</div>
		</div>
	</div>


